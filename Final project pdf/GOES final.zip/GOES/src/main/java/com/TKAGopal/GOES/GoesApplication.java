package com.TKAGopal.GOES;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoesApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoesApplication.class, args);
		System.out.println("GOES");
	}

}





